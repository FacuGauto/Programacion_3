<?php

class Proveedor
{
    public $id;
    public $nombre;
    public $email;
    public $foto;

    function __construct($id,$nombre,$email,$foto)
    {
        $this->id = $id;
        $this->nombre = $nombre;
        $this->email  = $email;
        $this->foto = $foto;

    }

    public function MostrarProveedor()
    {
        $datosProveedor = $this->id.",".$this->nombre.",".$this->email.",".$this->foto;
        return $datosProveedor;
    }

    public function cargarProveedor($nombreArchivo)
    {
        if(file_exists($nombreArchivo))
        {
            $arch = fopen($nombreArchivo,"a");
            fwrite($arch,"\n".$this->MostrarProveedor());
            fclose($arch);
        }
        else
        {
            $arch = fopen($nombreArchivo,"w");
            fwrite($arch,$this->MostrarProveedor());
            fclose($arch);
        }
    }

    static function buscarProveedor($nombreArchivo,$nombre)
    {
        $arrayProveedores = array();
        if(file_exists($nombreArchivo))
        {
            $arch = fopen($nombreArchivo,"r");
            while(!feof($arch))
            {
                $stringProveedor = trim(fgets($arch));
                $arrayProveedor = explode(",",$stringProveedor);
                $nuevoProveedor = new Proveedor($arrayProveedor[0],$arrayProveedor[1],$arrayProveedor[2],$arrayProveedor[3]);
                array_push($arrayProveedores,$nuevoProveedor);
            }
            fclose($arch);
            $bool = false;
            foreach($arrayProveedores as $auxProveedor)
            {
                
                if(strcasecmp($auxProveedor->nombre,$nombre)==0)
                {
                    echo $auxProveedor->MostrarProveedor() ."\n";
                    $bool = true;
                }
            }
            if($bool == false)
            {
                echo "No se encontro proveedor ".$nombre."</br>"; 
            }
        }
        else
        {
            echo "No existe el archivo proveedores.txt"; 
        }
    }

    static function mostrarProveedores($nombreArchivo)
    {
        $arrayProveedores = array();
        if(file_exists($nombreArchivo))
        {
            $arch = fopen($nombreArchivo,"r");
            while(!feof($arch))
            {
                $stringProveedor = trim(fgets($arch));
                $arrayProveedor = explode(",",$stringProveedor);
                $nuevoProveedor = new Proveedor($arrayProveedor[0],$arrayProveedor[1],$arrayProveedor[2],$arrayProveedor[3]);
                array_push($arrayProveedores,$nuevoProveedor);
            }
            fclose($arch);
        }
        else
        {
            echo "No existe el archivo proveedores.txt"; 
        }
        if(!empty($arrayProveedores))
            return $arrayProveedores;
    }

   /* function cargarProveedor($id,$nombre,$email,$foto,$nombreArchivo)
    {
        $proveedor = new Proveedor($nombre,$edad,$dni,$legajo);
        $proveedor->guardar_proveedor($nombreArchivo);        
        echo "Proveedor agregado exito";
    }*/

    
}

?>