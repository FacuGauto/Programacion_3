<?php
include_once "proveedor.php";

class Pedido
{
    public $producto;
    public $cantidad;
    public $idProveedor;
    
    function __construct($producto,$cantidad,$idProveedor)
    {
        $this->producto = $producto;
        $this->cantidad = $cantidad;
        $this->idProveedor = $idProveedor;
    }
    
    public function MostrarPedido()
    {
        $datosPedido = $this->producto.",".$this->cantidad.",".$this->idProveedor;
        return $datosPedido;
    }
    
    public function hacerPedido($nombreArchivo)
    {
        $arrayProveedores = Proveedor::mostrarProveedores("proveedores.txt");
        $encuentraProveedor = false;
        foreach($arrayProveedores as $auxProveedor)
        {
            if($auxProveedor->id == $this->idProveedor)
                $encuentraProveedor = true;
        }
        if($encuentraProveedor == true)
            if(file_exists($nombreArchivo))
            {
                $arch = fopen($nombreArchivo,"a");
                fwrite($arch,"\n".$this->MostrarPedido());
                fclose($arch);
            }
            else
            {
                $arch = fopen($nombreArchivo,"w");
                fwrite($arch,$this->MostrarPedido());
                fclose($arch);
            }
        else
            echo "No existe proveedor asignado</br>";
    }
    
    //caso: hacerPedido (post): Se recibe producto, cantidad y id de proveedor y se guarda en el archivo
    //pedidos.txt. Verificar que exista el id del proveedor.

    static function traerPedidos($nombreArchivo)
    {
        $arrayPedidos = array();
        if(file_exists($nombreArchivo))
        {
            $arch = fopen($nombreArchivo,"r");
            while(!feof($arch))
            {
                $stringPedido = trim(fgets($arch));
                $arrayPedido = explode(",",$stringPedido);
                $nuevoPedido = new Pedido($arrayPedido[0],$arrayPedido[1],$arrayPedido[2]);
                array_push($arrayPedidos,$nuevoPedido);
            }
            fclose($arch);
        }
        else
        {
            echo "No existe el archivo proveedores.txt"; 
        }
        if(!empty($arrayPedidos))
            return $arrayPedidos;
    }

    /*
    5- (2pt.) caso: listarPedidos(get): Se muestran todos los pedidos con los datos: 
    producto cantidad, id y nombre del proveedor*/
}



?>